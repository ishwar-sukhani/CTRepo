# HDFCLife
HDFCLife

The application demonstrates the basic usage of automation with html elements using xpath.
